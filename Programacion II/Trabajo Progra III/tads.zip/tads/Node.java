package tads;

class Node<E> {
  E element;
  Node<E> next;

  Node(E element, Node<E> next) {
    this.element = element;
    this.next = next;
  }
}
